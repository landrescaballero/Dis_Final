# Creative JS Coder


## Complete CRUD (Create, Read, Update, Delete) Operations including Pagination, Filter Data, Show entries, Control the Table Size Using HTML, CSS and JavaScript Local Storage.

<br>


<img src="./img/CRUD with Pagination.png">






